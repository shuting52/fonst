# Output Format

Use this exact structure unless the user asks for a different format.

## 内容判断

- 文字内容：
- 推荐字体类型：
- 匹配原因：
- 核心设计点：

## 设计规范

Describe:
- 字体风格：现代/传统/艺术/电竞等
- 材质质感：金属/水晶/玉石/木材等
- 色彩方案：主色+辅色+点缀色
- 光影效果：光源方向、高光、阴影
- 装饰元素：图标、符号、图案等
- 背景风格：颜色、纹理、氛围

## 图形构成

Describe:
- 背景层：颜色、纹理、渐变
- 主体层：文字造型、材质、立体效果
- 装饰层：图标、符号、图案
- 光影层：光源、高光、阴影、反射
- 氛围层：整体感觉、情绪、风格

## 单张图正向生图提示词

Provide one copy-ready prompt in a fenced text block.

The prompt should include:
1. 风格定义（3D/扁平/矢量/写实等）
2. 背景描述（颜色、纹理、氛围）
3. 主体文字（内容、字体风格、材质、颜色、立体效果）
4. 装饰元素（图标、符号、图案）
5. 光影描述（光源、高光、阴影）
6. 材质细节（金属/水晶/玉石等具体描述）
7. 色彩方案（主色、辅色、点缀色）
8. 质量标签（8K、超写实、照片级等）

## 负面提示词

Provide one copy-ready negative prompt in a fenced text block.

Common negative prompts:
```text
不要模糊，不要粗糙边缘，不要色彩失真，不要多余元素，不要文字变形，不要错别字，不要低清晰度，不要廉价模板感，不要过度杂乱，不要与主题无关的装饰。
```

## 可替换文字建议

Only include when useful. Provide 2-3 options for shorter or alternative text.

## 生图引导

Choose one:

- If imagegen is available:
  "当前环境支持生图。如果你需要，我可以基于上面的提示词直接生成一张字体设计图。"
- If imagegen is unavailable:
  "当前环境无法直接生图，你可以复制上面的提示词到 GPT-image、即梦、Midjourney 或其他工具使用。"

---

## JSON格式输出（可选）

When the user requests JSON format:

```json
{
  "图片元信息": {
    "主体类型": "字体设计类型",
    "风格": "设计风格",
    "背景": "背景描述"
  },
  "核心元素": [
    {
      "元素类型": "主文字",
      "内容": "文字内容",
      "设计细节": {
        "字体": "字体风格描述",
        "色彩": "颜色方案",
        "材质": "材质描述",
        "装饰": "装饰元素"
      }
    },
    {
      "元素类型": "装饰元素",
      "内容": "装饰描述"
    }
  ],
  "视觉特点": {
    "色彩氛围": "整体色彩氛围",
    "元素寓意": "设计寓意",
    "质感": "材质质感描述"
  }
}
```
