# 字体分类

Use this file to choose the best font style for the user's content.

## 电竞战队LOGO类

Best for:
- 电竞战队标识、游戏战队LOGO、竞技品牌、游戏俱乐部
- keywords: 电竞、战队、LOGO、游戏、竞技、俱乐部、队徽、吉祥物

Design language:
- 凶猛动物形象（龙、狮、狼、鹰、鲨鱼、虎、猩猩、兔等）
- 盾牌/徽章/尖刺轮廓
- 粗壮电竞字体，锐利倒角
- 金属质感描边或发光效果
- 高对比度配色（黑金、红黑、电光蓝、霓虹紫）
- 扁平化矢量+微立体质感
- 线条硬朗，视觉冲击力强
- aggressive, powerful, competitive

Color schemes:
- 黑金配色：权威、奢华
- 红黑配色：激情、力量
- 蓝白配色：科技、速度
- 紫黑配色：神秘、高端

## 品牌标识类

Best for:
- 企业LOGO、品牌标识、商业字体、奢侈品风格
- keywords: 品牌、LOGO、企业、公司、标识、高端、奢华、商业

Design language:
- 字母组合或文字标识
- 3D金属质感（银色、金色、铬色）
- 简洁现代或经典优雅
- 镜面反射效果
- 电影级光影
- premium, professional, timeless

Material options:
- 抛光金属/镀铬
- 拉丝金属
- 钻石/水晶镶嵌
- 琥珀/翡翠质感

## 姓名定制类

Best for:
- 个人姓名、情侣姓名、家族姓氏、个性化签名
- keywords: 姓名、名字、姓氏、定制、专属、个人、情侣

Design language:
- 单字或姓名组合
- 艺术化字体设计
- 立体浮雕效果
- 个性化装饰元素
- 材质多样（水晶、玉石、金属、木材）
- personal, unique, meaningful

Style options:
- 透明水晶/琉璃质感
- 彩虹渐变效果
- 3D立体剪纸风
- 鎏金浮雕风格
- 玉石雕刻质感

## 3D立体字体类

Best for:
- 3D效果字体、立体文字、材质字体
- keywords: 3D、立体、金属、水晶、玻璃、霓虹、材质

Design language:
- 明确的立体厚度
- 材质质感突出
- 光影效果丰富
- 高光与阴影对比
- dimensional, realistic, textured

Material types:
- 金属类：银色镜面、金色抛光、拉丝钢、铬金属
- 水晶类：透明水晶、粉色水晶、彩虹水晶
- 玻璃类：透明玻璃、彩色玻璃、磨砂玻璃
- 自然类：玉石、玛瑙、琥珀、木材、石材
- 特效类：霓虹发光、火焰效果、冰霜效果

## 励志主题类

Best for:
- 励志名言、个人成长、事业奋斗、正能量
- keywords: 励志、奋斗、拼搏、梦想、成功、正能量、成长

Design language:
- 鎏金/金色元素
- 雄鹰、山峰、太阳等象征元素
- 橄榄枝、五角星装饰
- 温暖明亮的光线
- 积极向上的氛围
- inspirational, motivational, powerful

Common elements:
- 雄鹰展翅
- 长城/山峰
- 鎏金文字
- 橄榄枝/花环
- 五角星

## 爱情主题类

Best for:
- 情侣姓名、婚礼主题、纪念日、浪漫设计
- keywords: 爱情、情侣、婚礼、纪念日、浪漫、520、情人节

Design language:
- 爱心元素
- 粉色/红色主色调
- 玫瑰、蝴蝶装饰
- 温馨柔和的光线
- 浪漫氛围营造
- romantic, sweet, intimate

Common elements:
- 爱心/LOVE标识
- 玫瑰花/花瓣
- 蝴蝶/丝带
- 情侣剪影
- 丘比特/箭

## 爱国主题类

Best for:
- 中国风元素、爱国主题、国旗色彩、传统文化
- keywords: 爱国、中国、国旗、中国红、鎏金、华表、长城

Design language:
- 中国红+鎏金配色
- 五角星、国旗元素
- 长城、华表、和平鸽
- 鎏金浮雕效果
- 庄重热烈的氛围
- patriotic, solemn, proud

Common elements:
- 五星红旗
- 长城/华表
- 和平鸽
- 五角星
- 鎏金装饰

## 艺术创意类

Best for:
- 矢量插画、手绘涂鸦、抽象变形、实验设计
- keywords: 艺术、创意、矢量、涂鸦、抽象、手绘、插画

Design language:
- 非传统字体形态
- 色彩丰富或极简对比
- 手绘/涂鸦质感
- 抽象变形
- artistic, creative, experimental

Style options:
- 矢量插画风格
- 手绘涂鸦风格
- 极简几何风格
- 抽象变形风格
- 3D剪纸风格

## 封面字体类

Best for:
- 社交媒体封面、海报标题、视频封面
- keywords: 封面、标题、海报、视频、社媒、小红书

Design language:
- 醒目大标题
- 高对比度
- 清晰易读
- 符合平台风格
- eye-catching, clear, platform-appropriate

Platform considerations:
- 小红书：3:4竖版，手写风格，贴纸感
- 抖音：9:16竖版，动感字体，霓虹效果
- 微信：1:1方形，简洁大方，商务感

## 商业应用类

Best for:
- 产品包装、商品设计、商业宣传
- keywords: 包装、商品、商业、宣传、产品、销售

Design language:
- 品牌一致性
- 专业品质感
- 符合产品定位
- commercial, professional, branded

Industry styles:
- 食品类：温暖、食欲感
- 科技类：现代、未来感
- 奢侈品：高端、精致感
- 日用品：清新、亲切感
