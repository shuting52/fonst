# Prompt Templates

This file contains comprehensive prompt templates for various font design types. Use these as references when generating prompts for users.

---

## 一、电竞战队LOGO类

### 1.1 凶猛动物系列

#### 雄鹰主题
```
超写实的电竞战队标志设计，纯黑背景（营造威严锐利氛围）。主体为极具攻击性的雄鹰形象：羽毛以深棕渐变为主，翼羽层次分明带金属哑光质感；双眼金色、目光如炬，嘴巴大张露弯曲锐喙与红色舌部，表情威慑力十足；双翼半展、肌肉虬结充满力量，前爪如利刃前伸，姿态掌控感强烈；雄鹰外沿有金色描边强化轮廓。下方是白色立体文字"[队名]"（字体刚硬，边缘有金色与黑色双层描边，质感如抛光金属印刷字体）。整体光线聚焦于雄鹰与文字，突出羽毛纹理细节、肌肉力量感与文字边缘清晰度，细节精准（羽毛分层、喙尖锐度、文字笔画边缘），材质表现极致（羽毛蓬松与金属感对比、文字光滑金属质感），8K分辨率，风格硬核充满制空竞技气势。--no 模糊，no 粗糙边缘，no 色彩失真，no 多余元素
```

#### 猛虎主题
```
超写实的电竞战队风格标志设计，黑色哑光背景（营造霸气凌厉氛围）。主体为凶悍的猛虎形象：虎纹以橙黑为主，夹杂白纹，质感如绸缎与火焰的结合；双眼散发红色光芒，嘴巴大张露出尖锐白牙与粉色舌信，表情极具压迫感；虎爪尖锐，呈橙黑渐变，牢牢抓握下方文字。下方是立体加粗的白红渐变中文"[队名]"（边缘有黑色描边，增强立体感与视觉冲击力，字体风格厚重，带有光泽质感）。整体采用侧光突出猛虎的立体轮廓与虎纹细节、文字的光影层次，细节精准，材质表现极致，8K分辨率，风格偏向力量、统治感十足的徽章设计。--no 模糊，no 粗糙边缘，no 色彩失真，no 多余元素
```

#### 白鲨主题
```
超写实风格电竞标志，纯黑背景，主体为一头矫健的白鲨，鲨鱼表皮呈纯净白色，带有湿润的光泽质感，鳃部线条清晰，嘴巴大张露出锋利的灰白色牙齿与粉色口腔，眼睛为冰蓝色，透着冰冷的攻击性，尾鳍有力摆动，仿佛在黑色深海中迅猛穿梭。下方是立体加粗的红白渐变中文"[队名]"（边缘有黑色描边，字体风格硬朗，带有哑光与高光的质感对比），整体采用侧光突出白鲨的立体轮廓与表皮细节、文字的光影层次，细节精准，材质表现极致，8K分辨率，风格偏向硬核、速度感十足的徽章设计。--no 模糊，no 粗糙边缘，no 色彩失真，no 多余元素
```

#### 巨狼主题
```
专业电竞战队LOGO设计，核心文字为"[队名]"。主体设计包含一个霸气的盾牌、尖刺或徽章轮廓，中央融合了狼的锋利抽象几何图形，象征力量与速度。文字"[队名]"采用加粗的定制电竞字体，带有锐利的倒角、金属质感描边或发光效果。配色采用高对比度的电竞色调（黑金、红黑、电光蓝或霓虹紫）。背景为纯色或微弱的暗纹，突出LOGO主体。整体风格为扁平化矢量插画与微立体质感结合，线条硬朗，视觉冲击力极强，适合战队品牌传播。画面中请包含第二行文字："[队名拼音]"，需与主标题协调。
```

#### 金刚猩猩主题
```
超写实的电竞战队风格标志设计，深棕哑光背景（营造厚重强悍氛围）。主体为壮硕的金刚猩猩头部形象：毛发以深棕为主，夹杂黑、土黄纹理，质感如岩石与皮革的结合；双眼散发暗黄色光芒，嘴巴大张露出粗钝黄牙与紫黑舌信，表情极具爆发力；猩猩手掌宽厚，呈棕黑相间色，重重拍在下方文字上。下方是立体加粗的棕黄渐变文字"[队名]"（边缘有白色描边，增强立体感与视觉冲击力，字体风格粗犷，带有磨砂质感）。整体采用底光突出猩猩头的立体轮廓与毛发细节、文字的光影层次，细节精准，材质表现极致，8K分辨率，风格偏向强悍、力量碾压的徽章设计。--no 模糊，no 粗糙边缘，no 色彩失真，no 多余元素
```

#### 疾风兔主题
```
超写实的电竞战队风格标志设计，浅灰哑光背景（营造极速反应氛围）。主体为迅捷的疾风兔头部形象：皮毛以雪白为主，夹杂灰、天蓝纹理，质感如疾风与流云的结合；双眼散发闪电蓝光芒，嘴巴微张露出细小白牙与粉红舌信，表情极具敏捷性；兔爪带风痕，呈白蓝相间色，快速点在下方文字上。下方是立体加粗的白蓝渐变文字"[队名]"（边缘有灰黑描边，增强立体感与视觉冲击力，字体风格流畅，带有风速光效质感）。整体采用动态光突出兔头的灵动轮廓与皮毛细节、文字的速度层次，细节精准，材质表现极致，8K分辨率，风格偏向敏捷、极速反应的徽章设计。--no 模糊，no 粗糙边缘，no 色彩失真，no 多余元素
```

#### 龙主题
```
张开嘴的龙的程式化徽章为特色，展示了锋利的牙齿和红色的舌头。龙被设计成一种动态的姿势，暗示着运动或侵略。在龙的下方，有一个突出显示字母"[队名]"的标志。会徽的配色方案包括金色、黑色、红色和白色，使其外观大胆醒目。这种类型的图像通常用于运动队、游戏组织或其他竞争实体，以传达力量和凶猛。
```

#### 蛇主题
```
一种食肉动物蛇游戏元素标志，它的嘴张得大大的，露出锋利的牙齿。细节丰富，站立的姿势。背景是白色。下面写着一个队名"[队名]"文字。蛇和背景用五颜色勾勒出来。整体徽标具有3D效果。
```

### 1.2 盾牌徽章系列

```
Elite high school track and field logo featuring an aggressive [动物] head centered inside a modern shield crest with sharp edges and high contrast, set against a dark navy blue background with subtle track oval lines, incorporating a navy blue and Vegas gold color scheme, with bold collegiate-style text reading "[队名]" in gold at the top and "[队名拼音]" in white at the bottom, emphasizing a clean athletic design with professional sports branding, minimalistic and vector-style elements, and gold and white accents, avoiding cartoonish or exaggerated mascot representations, with a focus on sharp lines and a sleek overall aesthetic.
```

### 1.3 3D金属质感系列

```
Logo corporativo de lujo con las iniciales "[队名]" monograma en el centro, estilo 3D metálico, combinación oro brillante, plata y azul cromados, acabado espejo reflectante, iluminación tipo estudio cinematográfico.
```

```
A luxury 3D logo featuring the text "[队名]" in gold 3D lettering. The logo is placed on a dark marble wall background with soft warm spotlighting. The style is modern-classic. High contrast, cinematic lighting, 8k, photorealistic details.
```

```
Ultra premium 3D metallic logo design for company. An abstract emblem where letters are artistically intertwined like two flowing metallic ribbons — one gold, one silver chrome — merging together to form a unified luxurious mark symbolizing mutual prosperity. The ribbons have realistic 3D metallic shading with light reflections and depth. Deep dark navy background. Photorealistic metallic rendering, dramatic lighting from behind creating subtle backglow.
```

---

## 二、3D立体字体类

### 2.1 金属质感

#### 银色镜面金属
```
3D立体文字"[文字]"，亮银色镜面金属材质，边缘带有蓝色光泽描边与反光，置于纯深蓝色渐变平面背景上（从#0055FF到#0033AA），顶右45°光源角度，形成明显的立体阴影与高光反射，4K分辨率，超写实金属质感。
```

#### 金色抛光金属
```
A sleek, modern personal brand logo. The interlocking letters "[文字]" rendered as high-quality 3D illuminated neon glass, emitting intense orange light (#ff751f). The design hovers over a dark, textured black surface representing carbon fiber or dark metal, catching the orange reflections. Luxurious, tech-noir aesthetic, 8k resolution render, dramatic shadows.
```

#### 镀铬质感
```
黑色背景，画面中心横向排布一行极细的几何符号字体"[文字]"，呈未来感的连笔和直角线条构成，银灰色金属质感，带有微弱蓝白色光晕与边缘高光，表面有轻微磨砂质感与镜面反射，整体偏冷调科幻风格。采用简洁无衬线字体，颜色接近灰白。光源来自左上方，阴影清晰，整体氛围简约但具有强烈的文本艺术感。
```

### 2.2 水晶/玻璃质感

#### 透明水晶
```
A stunning 3D rendered composition showcasing the name "[文字]" crafted from translucent pink crystal letters with a glossy, reflective surface that catches and refracts light with prismatic brilliance. The crystalline text displays dimensional depth with precisely beveled edges and internal light refractions that create a luminous, gem-like appearance, while each letter sparkles with delicate rainbow highlights. The entire composition rests against a pure dark pink background with soft studio lighting that enhances the crystal materials' transparency.
```

#### 彩虹渐变水晶
```
{
  "作品整体信息": {
    "主题类型": "个性化艺术字设计",
    "核心元素": "姓名+励志文案+爱国标识",
    "风格特点": "透明立体、彩虹渐变、琉璃/水晶质感"
  },
  "元素拆解": [
    {
      "元素名称": "主字"[文字]"",
      "视觉特征": {
        "材质效果": "透明立体（类似水晶/琉璃）",
        "色彩方案": "彩虹渐变（红→橙→黄→绿→蓝→青）",
        "造型特点": "笔画夸张变形，增强艺术感"
      },
      "功能定位": "核心视觉焦点，个性化姓名展示"
    }
  ]
}
```

#### 玻璃管效果
```
由透明粉色玻璃管打造的汉字"[文字]"的3D渲染图。玻璃管表面光滑有光泽，带有细微的折射与反射，展现出玻璃的清澈与精致。汉字的笔画由交织、弯曲的玻璃管构成，边缘带有粉色点缀。背景为简洁的浅灰色，柔和均匀的光线突出玻璃的透明感与柔和的粉色调。极简风格，超细节，照片级真实玻璃纹理，锐利对焦，营造优雅流畅的美学氛围。
```

### 2.3 玉石质感

```
超写实的玉石艺术字设计，主体为巨型立体汉字"[文字]"（以玛瑙与玉石为材质，纹理呈现黄、橙、白、灰等自然色调，带有金色裂纹（金缮工艺质感），部分区域如琥珀般通透，内含红色、金色碎屑点缀，质感温润且富有层次）。汉字表面装饰丰富禅意元素：白色与粉色莲花（花瓣纹理细腻，色彩鲜活）；微型佛像（有玛瑙与玉石质感，神态庄严）；金色流苏与珠串（垂坠感自然，金属光泽柔和）；琉璃瓶（以玛瑙与玉石为材质，通透如琥珀）；绿色竹叶（脉络清晰）；透明水滴（形态圆润，折射光线）。每个笔画造型流畅圆润，表面有高光反射，如抛光玉石般光滑。背景为深蓝色渐变，底部有浅灰色反光面。整体光线为柔和的侧光，8K分辨率。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

### 2.4 木材质感

```
create a wooden logo with "[文字]"
```

```
墙面装饰摆件的照片，主体为"[文字]"字样，由纹理饱满、带有清晰橡木纹路的暖色调木片精心拼接而成。每一块木片都有着细微的纹理差异，边缘点缀着柔和的霓虹金边，晕开淡淡的琥珀光晕，让字体层次分明、暖意十足。整套装饰装置安装在浅灰色肌理墙面上，窗外自然光洒落，在墙面投下淡淡的光影。整体空间被柔和的漫射光线笼罩，既凸显出木材天然的纹路质感，霓虹镶边又为这间雅致的室内空间营造出温馨又兼具现代感的氛围。
```

### 2.5 霓虹发光

```
A captivating 8D design of the "[文字]" logo, featuring the letters intricately crafted in a mesmerizing gothic style. The design exudes dark energy, with fiery red elements swirling around, creating a sense of intensity and passion. The firelight casts realistic, burning shadows on the letters, making them appear alive with a modern atmosphere. The glass-like material subtly glows, highlighting the brand's elegance and sophistication. The shiny gold text adds a touch of luxury and exclusivity.
```

---

## 三、励志主题类

### 3.1 鎏金励志风格

```
超写实的励志主题艺术设计，浅米色渐变背景（营造雅致氛围）。主体包含多组立体元素：顶部黑色与红色艺术字"[主文字]"（红色"靠"字尤为突出，笔画富有张力）；左侧红色雄鹰图案（羽翼舒展，细节精致，力量感十足）；中央大号黑色立体"[姓名]"字（笔画饱满，边缘带银色高光，立体感强）；右侧红色矩形框内有"好運 Good Luck 100%"字样，旁有红色祥云装饰及黑色文字"前程似锦 一帆风顺"；底部红色艺术签名。整体光线柔和明亮，突出立体字的层次感、雄鹰的灵动与文字的励志氛围，细节精准，材质表现极致，8K分辨率，氛围积极且充满励志正能量。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

### 3.2 渐变鎏金风格

```
超写实的励志主题渐变鎏金立体橙金暖调艺术设计，浅米色渐变背景（营造温馨雅致氛围）。主体为圆形构图，两侧环绕橙色向金色渐变鎏金橄榄枝装饰（叶片纹理细腻，边缘暖调流光渐变，质感如金属锻造与橙珐琅结合般精致，立体层次分明），底部点缀橙金渐变鎏金五角星（棱角分明，光泽从橙到金自然过渡，温暖亮眼）。中央巨型橙色渐变鎏金艺术字"[文字]"（边缘带有橙色向银色渐变金属描边，质感如金属雕刻般厚重，立体浮雕效果强烈）；顶部橙色渐变鎏金艺术字"遇见幸福"（笔触灵动，带有橙金渐变鎏金丝带与爱心装饰）。整体光线柔和且有侧光，8K分辨率。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

### 3.3 凹压痕风格

```
超写实的励志主题凹压痕渐变流光艺术字设计，浅灰色纹理背景（质感如细腻皮革，营造高级雅致氛围）。主体包含多组凹压痕元素：巨型红金渐变凹压痕艺术字"[文字]"（字体笔触灵动，压痕处呈红色向金色渐变，凹陷底部流光随光线流动，边缘光滑如珐琅，立体感强烈）；黑金渐变凹压痕小字"[副标题]"（字体规整，压痕带细微流光效果，与背景纹理融合自然）；右侧红金渐变凹压痕印章风格文字。整体光线柔和且有侧光，突出渐变凹压痕文字的流光质感，8K分辨率。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

---

## 四、爱情主题类

### 4.1 情侣姓名设计

```
{
  "图片元信息": {
    "作品类型": "情侣/婚恋主题的个性化立体图文设计",
    "风格定位": "浪漫甜美+立体浮雕质感",
    "背景基调": "浅米色柔焦底，搭配漂浮的粉色花瓣（带星光效果），营造温馨氛围"
  },
  "核心元素详情": [
    {
      "主体框架": "圆形装饰框",
      "细节": "外层为金色浮雕花纹边框（复古华丽质感），内层为白色立体基底，形成层次分明的"画框"效果"
    },
    {
      "核心标识（姓名）": {
        "内容": "[男方姓氏]、[女方姓氏]（情侣姓氏）",
        "设计": "黑色立体字（带白色底座，增强浮雕感），字体为圆润的艺术体，契合浪漫主题"
      },
      "情感符号": {
        "爱心元素": "红色立体爱心，内部嵌入"LOVE"白色字母，位于两姓氏之间，作为情感连接点"
      }
    },
    {
      "文案元素": "执子之手 与子偕老",
      "设计": "黑色手写风格字体，排版于爱心下方，传递传统婚恋祝福"
    }
  ]
}
```

### 4.2 浪漫氛围设计

```
超写实的浪漫爱情主题艺术设计，浅米色渐变背景（营造温馨雅致氛围）。主体包含多组立体元素：左侧大号黑色立体"[男方姓氏]"字（笔画流畅，立体感强）；右侧黑色立体"[女方姓氏]"字，旁有红色文字"始于初见 止于终老 I LOVE YOU"；中间红色立体文字"往后余生 相伴相随"；下方黑色箭头造型，旁有卡通情侣形象（男孩似在送花，女孩姿态温柔，造型可爱）。整体光线柔和明亮，突出立体字的层次感、卡通形象的甜蜜与文字的浪漫，细节精准，材质表现极致，8K分辨率，氛围浪漫甜蜜且充满爱意。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

---

## 五、爱国主题类

### 5.1 鎏金中国红风格

```
超写实的爱国主题鎏金中国红立体3D艺术设计，大红色渐变背景（带有鎏金线条勾勒的山水纹理，鎏金与中国红交融，营造庄重热烈氛围）。主体包含多组鎏金中国红立体3D元素：左侧圆形鎏金中国红相框（边框为中国红丝带缠绕，边缘点缀鎏金立体五角星，3D层次感鲜明）；中央巨型鎏金中国红艺术字"[文字]"（字体以中国红为底，边缘包裹鎏金，立体浮雕质感强烈，如纯金锻造般精致，3D立体层次分明）；下方鎏金文字"红旗漫卷时 青春正奋斗"（字体规整，鎏金光泽柔和，与中国红背景形成鲜明对比）；底部鎏金中国红长城浮雕（城墙、山峦细节精致，质感如金属雕刻般厚重）。整体光线柔和且有侧光，8K分辨率。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

### 5.2 徽章风格

```
超写实的爱国主题艺术徽章设计，浅灰色渐变背景（带有细腻的磨砂质感，营造庄重雅致氛围）。主体为心形徽章，外轮廓为金色金属边框，边缘镶嵌透明钻石（切割面精准，折射出璀璨光芒），内部底色为红色珐琅（质感光滑且有光泽，如优质釉面般饱满）。徽章元素包括：中央巨型金色艺术字"[文字]"；右侧竖排金色文字"不忘初心 牢记使命"；下方金色文字"爱我中华"；左侧金色和平鸽（羽毛纹理细腻，翅膀姿态灵动）；和平鸽旁有两颗金色五角星；底部金色长城浮雕。整体光线柔和且有侧光，8K分辨率。--no 模糊，no 粗糙质感，no 色彩失真，no 多余元素
```

---

## 六、艺术创意类

### 6.1 矢量插画风格

```
矢量插画，标志，黑色背景，创意字体设计Logo，线条流畅且富有艺术感，各种色块组合在一起的中文"[文字]"设计灵感：将字体进行抽象变形，创造出独特的节奏和动感，给人以强烈的视觉冲击。高级感，扁平化，大师作品。
```

### 6.2 手绘涂鸦风格

```
手绘涂鸦风格中文字"[文字]"，字体结构锋利、动感、层叠式排布，采用橙色、绿色、粉红主调，带黑色粗描边与高光阴影处理，营造出立体爆炸感。笔画交错张扬，具有强烈街头视觉风格。画面中融入橙子、猫头、星点飞溅等涂鸦常见元素，色彩浓烈、构图丰满。黑色背景。
```

### 6.3 3D剪纸风格

```
{
  "风格": "3D立体剪纸风+卡通插画",
  "主体元素": [
    {
      "类型": "文字元素",
      "内容": "[文字]",
      "样式": "黑色书法字体+白色立体剪纸底座"
    },
    {
      "类型": "装饰元素",
      "内容": "红色爱心（带白色立体底座）"
    }
  ],
  "背景": "浅米色纯色背景",
  "整体氛围": "励志、个性、潮流"
}
```

---

## 七、品牌标识类

### 7.1 奢侈品牌风格

```
Create a luxurious 3D logo for a premium brand. The logo design should feature a bold metallic letter "[文字]" as the central emblem. Use a gunmetal gray base with deep crimson red highlights that flow across the curves of the emblem, giving a sleek, futuristic energy. Typography: elegant serif font, polished and embossed, finished in brushed platinum with realistic reflections. Background: a dark glass office wall with soft blurred reflections and diffused studio lighting. Apply cinematic depth of field, subtle reflections on the floor, and realistic metallic texture. Mood: powerful, refined, and visionary. Render in ultra-realistic 3D, high resolution, with controlled ambient lighting and crisp detail on every metallic surface.
```

### 7.2 科技品牌风格

```
Design a modern and professional logo for a tech service brand. The logo should feature bold, stylized initials "[文字]" in a sleek combination of blue and yellow colors with a glossy and slightly 3D effect. Use a dark textured background to enhance contrast.
```

---

## 八、通用负面提示词

```text
不要模糊，不要粗糙边缘，不要色彩失真，不要多余元素，不要文字变形，不要错别字，不要低清晰度，不要廉价模板感，不要过度杂乱，不要与主题无关的装饰，不要九宫格，不要合集图，不要多张封面，不要动漫人物（除非用户指定），不要欧美人物（除非用户指定），不要遮挡主体，不要人脸变形，不要手部畸形。
```

---

## 九、质量标签库

### 分辨率标签
- 8K分辨率
- 4K分辨率
- 超高清
- 高清晰度

### 写实程度标签
- 超写实
- 照片级真实
- 电影级渲染
- Octane渲染
- 逼真细节

### 材质标签
- 金属质感
- 水晶质感
- 玉石质感
- 玻璃质感
- 木材质感
- 霓虹效果

### 光影标签
- 电影级光影
- 柔和侧光
- 顶光照明
- 戏剧性光效
- 工作室灯光

---

## 使用说明

1. 根据用户需求选择合适的模板类型
2. 替换模板中的 `[文字]`、`[队名]` 等占位符
3. 根据用户偏好调整颜色、材质、风格等参数
4. 添加适当的负面提示词
5. 确保提示词包含完整的风格定义、背景、主体、装饰、光影、材质、色彩和质量标签
